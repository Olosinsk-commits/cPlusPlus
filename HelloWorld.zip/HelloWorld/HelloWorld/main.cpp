#include <iostream>;

using namespace std;

int main()
{
	cout << "Hello World!" << endl;
	cout << "Some other text" << endl;
	system("pause");
	return 0;
}