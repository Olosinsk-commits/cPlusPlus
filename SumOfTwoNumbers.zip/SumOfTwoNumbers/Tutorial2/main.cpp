#include <iostream>;
using namespace std;

int main()
{
	double a;
	double b, c;

	a = 0;
	b = 0;
	cout << "Enter a: ";
	cin >> a;
	cout << "Enter b: ";
	cin >> b;
	c = a + b;
	cout << "Value of variable c is: " << c << endl;
	system("pause");
	return 0;
}